# BDA400 Assignment 2 — functions for importing and analyzing stocks
# Data source: Yahoo Finance via quantmod; requires internet access.
# Run 01_setup.R first, then source this file.

read_portfolio <- function(path = "portfolio.txt") {
  if (!file.exists(path)) stop("Cannot find portfolio file: ", path)
  symbols <- trimws(readLines(path, warn = FALSE))
  symbols <- unique(symbols[nzchar(symbols) & !startsWith(symbols, "#")])
  if (length(symbols) == 0L) stop("Portfolio contains no stock symbols.")
  if (any(!grepl("^[A-Za-z0-9.^_-]+$", symbols))) stop("Invalid stock symbol found in portfolio.")
  symbols
}

load_stock_data <- function(portfolio_file = "portfolio.txt", from = "2025-01-01", to = Sys.Date()) {
  if (!requireNamespace("quantmod", quietly = TRUE)) stop("Install quantmod first (01_setup.R).")
  symbols <- read_portfolio(portfolio_file)
  results <- list()
  for (symbol in symbols) {
    cat("Downloading", symbol, "...\n")
    raw <- tryCatch(quantmod::getSymbols(symbol, src = "yahoo", from = from,
                                        to = to, auto.assign = FALSE, warnings = FALSE),
                    error = function(e) {
                      warning(sprintf("Could not download %s: %s", symbol, conditionMessage(e)))
                      NULL
                    })
    if (is.null(raw) || NROW(raw) == 0) next
    # quantmod's OHLC functions use the named series and preserve the trading dates.
    adjusted <- tryCatch(quantmod::Ad(raw), error = function(e) NULL)
    if (is.null(adjusted) || all(is.na(adjusted))) adjusted <- quantmod::Cl(raw)
    data <- data.frame(Date = as.Date(zoo::index(raw)),
                       Open = as.numeric(quantmod::Op(raw)),
                       High = as.numeric(quantmod::Hi(raw)),
                       Low = as.numeric(quantmod::Lo(raw)),
                       Close = as.numeric(quantmod::Cl(raw)),
                       Volume = as.numeric(quantmod::Vo(raw)),
                       Adjusted = as.numeric(adjusted))
    results[[symbol]] <- data
  }
  if (length(results) == 0L) stop("No stock data could be loaded. Check internet, dates and symbols.")
  results
}

# Approximate numeric mode: for unique (continuous) prices, no mode is reported.
numeric_mode <- function(x) {
  x <- x[is.finite(x)]
  if (!length(x)) return(NA_real_)
  counts <- table(x)
  if (max(counts) == 1L) return(NA_real_)
  winners <- as.numeric(names(counts)[counts == max(counts)])
  if (length(winners) != 1L) return(NA_real_)  # multiple modes -> no unique mode
  winners
}

calculate_statistics <- function(stock_df, symbol = "unknown", n = 20L) {
  if (!requireNamespace("TTR", quietly = TRUE)) stop("Install TTR first (01_setup.R).")
  stopifnot(is.data.frame(stock_df), all(c("Date", "Adjusted") %in% names(stock_df)))
  x <- as.numeric(stock_df$Adjusted)
  keep <- is.finite(x)
  if (!any(keep)) stop("No valid adjusted prices for ", symbol)
  if (!is.numeric(n) || length(n) != 1 || is.na(n) || n < 1 || n != as.integer(n)) stop("n must be a positive whole number")
  stock_df$SMA20 <- as.numeric(TTR::SMA(x, n = as.integer(n)))
  available_sma <- stats::na.omit(stock_df$SMA20)
  last_sma <- if (length(available_sma)) tail(available_sma, 1) else NA_real_
  stats <- data.frame(Symbol = symbol, Observations = sum(keep),
                      FirstDate = min(stock_df$Date[keep]), LastDate = max(stock_df$Date[keep]),
                      Mean = mean(x[keep]), Mode = numeric_mode(x),
                      Median = median(x[keep]), StdDev = if (sum(keep)>1) stats::sd(x[keep]) else NA_real_,
                      LatestAdjusted = tail(x[keep], 1),
                      LatestSMA = as.numeric(last_sma))
  list(data = stock_df, summary = stats)
}
