# BDA400 Assignment 2 — install required packages (run once in RStudio)
required_packages <- c("quantmod", "TTR")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0) {
  install.packages(missing_packages, repos = "https://cloud.r-project.org")
}
cat("Package installation/check finished. Verify installed versions below.\n")
for (pkg in required_packages) {
  cat(pkg, as.character(utils::packageVersion(pkg)), "\n")
}
