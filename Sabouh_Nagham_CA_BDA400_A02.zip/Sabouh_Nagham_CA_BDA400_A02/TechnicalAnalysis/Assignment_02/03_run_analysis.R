# BDA400 A02 — Execute from the Assignment_02 folder
# Source installation script once first, if packages are missing.
source("02_stock_functions.R")
stocks <- load_stock_data("portfolio.txt", from = "2025-01-01")
results <- lapply(names(stocks), function(symbol) calculate_statistics(stocks[[symbol]], symbol))
names(results) <- names(stocks)
all_statistics <- do.call(rbind, lapply(results, function(z) z$summary))
row.names(all_statistics) <- NULL
cat("\nSTATISTICS BASED ON ADJUSTED DAILY CLOSE\n")
print(all_statistics, row.names = FALSE)
for (symbol in names(results)) {
  cat("\n", symbol, " — first 6 imported rows\n", sep = "")
  print(utils::head(results[[symbol]]$data))
}
if (!dir.exists("outputs")) dir.create("outputs")
write.csv(all_statistics, "outputs/stock_statistics.csv", row.names = FALSE)
for (symbol in names(results)) {
  safe_symbol <- gsub("[^A-Za-z0-9_-]", "_", symbol)
  stock <- results[[symbol]]$data
  utils::write.csv(stock, file.path("outputs", paste0(safe_symbol, "_stock_data.csv")), row.names = FALSE)
  png(file.path("outputs", paste0(safe_symbol, "_price_sma.png")), width = 1100, height = 650)
  plot(stock$Date, stock$Adjusted, type = "l", lwd = 2, col = "#1565C0",
       xlab = "Date", ylab = "Adjusted close (USD)", main = paste(symbol, "Adjusted Close and 20-Day SMA"))
  lines(stock$Date, stock$SMA20, col = "#D35400", lwd = 2)
  legend("topleft", legend = c("Adjusted close", "20-day SMA"),
         col = c("#1565C0", "#D35400"), lty = 1, lwd = 2, bty = "n")
  grid()
  dev.off()
}
cat("\nSaved CSV results and PNG charts in outputs/.\n")
