# Assignment 02 — Technical Analysis Using R: Preliminary Stage

**Student:** Sabouh Mohamed | **Course:** BDA400 | **College:** CDI College

## Files
- `portfolio.txt`: sample stock symbols AAPL, MSFT, GOOG, one per line.
- `01_setup.R`: installs/checks `quantmod` and `TTR`.
- `02_stock_functions.R`: portfolio reader, Yahoo Finance importer, 20-day simple moving average and mean/mode/median/standard deviation.
- `03_run_analysis.R`: displays data and statistics; exports CSVs and PNG charts to `outputs/`.
- `Sabouh_Mohamed_CA_BDA400_A02_Report.docx`: report with clearly labeled screenshot placeholders.
- `Sabouh_Mohamed_CA_BDA400_A02_Cover.docx`: LMS cover page template.

## Running the project in RStudio
1. Install R and RStudio. Open RStudio, then **Session > Set Working Directory > Choose Directory** and select this `Assignment_02` directory.
2. Open and run `01_setup.R` once to install `quantmod` and `TTR` (internet needed).
3. Open and source `03_run_analysis.R`. It will read `portfolio.txt`, download daily stock data, print imported data and statistics, and write results to `outputs/`.
4. Capture genuine RStudio screenshots of installation, package versions, portfolio, execution, data output, statistics, and PNG charts; insert these in the Word report.
5. Inspect CSV values, verify statistics independently, and add the actual GitHub URL to the cover. Upload this folder to the `TechnicalAnalysis` repository.

## Assumptions and cautions
- Stock prices are imported from an external public data source rather than generated locally. Dates and results depend on when the script runs, market availability and revisions by the source.
- Calculations use **Adjusted** daily closing prices; moving average is a 20-trading-day SMA.
- "Mode" is reported as `NA` when no price repeats or more than one price ties for most frequent. With continuous prices, this is common.
- The report is a documentation template, not proof of installation or successful execution.
- No investment recommendations are made.
