# TechnicalAnalysis — BDA400

CDI College BDA400 technical analysis coursework. This repository is intended to use a dedicated folder for each assignment.

## Assignment 02 — Preliminary Stage

See `Assignment_02/` for the stock-symbol portfolio, R scripts, instructions, and report. Run scripts from the `Assignment_02` working directory. The scripts retrieve public historical stock prices from Yahoo Finance using `quantmod`; internet access is required. Historical market data are **not synthetic**, and may not be available or reliable for every ticker/date. No real or private information is included.

**Status:** Prepared, not confirmed as executed in RStudio. Installation and output screenshots must be added by the student.
